# Import libraries
import serial
import speech_recognition as sr
 
# Initialize serial communication
ser = serial.Serial('COM4', 9600)

# Initialize the recognizer
recognizer = sr.Recognizer()

try:
    while True:
        try:
            # Capture audio from the microphone for 2 seconds
            with sr.Microphone() as source:
                print("Say something.")
                audio = recognizer.listen(source, phrase_time_limit=2)
                
            # Use Google Web Speech API to recognize the speech
            print('Processing voice ...')
            text = recognizer.recognize_google(audio, language='ar-EG')
            print(f'You said: {text}')
            
            # Send command to NodeMCU
            if text == 'نور اللمبه':
                ser.write('1'.encode())
            elif text == 'اطفي اللمبه':
                ser.write('0'.encode())
        except sr.UnknownValueError:
            print("Google Web Speech API could not understand audio.")
        except sr.RequestError:
            print("Could not request results from Google Web Speech API.")
        finally:
            repeat = input('\nRepeat? ')
except:
    # Close the serial connection
    ser.close()
    print("Serial connection closed.")
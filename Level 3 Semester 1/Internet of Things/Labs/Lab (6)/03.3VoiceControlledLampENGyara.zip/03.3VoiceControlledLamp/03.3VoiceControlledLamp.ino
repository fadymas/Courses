#define LED_PIN D6                        // Define LED pin

void setup() {
  Serial.begin(9600);                     // Start serial monitor
  pinMode(LED_PIN, OUTPUT);               // Initialize the pin D6 as an output
}

void loop() {
  // Read the incoming byte if available
  if(Serial.available()){                 // Check if there is a message available
    char cmd = Serial.read();             // Read the incoming byte

    if(cmd == '1')                        // If command is '1'
      digitalWrite(LED_PIN, HIGH);        // Turn on LED
    else if(cmd == '0')                   // If command is '0'
      digitalWrite(LED_PIN, LOW);         // Turn off LED
  }
}

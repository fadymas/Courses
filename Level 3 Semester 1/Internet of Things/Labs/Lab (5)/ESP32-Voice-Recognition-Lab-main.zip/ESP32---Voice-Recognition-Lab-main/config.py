# WiFi Configuration
# Fill in your WiFi (SSID) and password below.

WIFI_SSID = "your-wifi-name"
WIFI_PASSWORD = "your-wifi-password"

"""
ESP32 LED Controller - Shared Module
=====================================
Contains all ESP32 communication functions used by both GUI and voice control.
"""

import socket
import requests
import time


class ESP32Controller:
    """Handles all communication with the ESP32"""
    
    def __init__(self, esp32_ip=None, port=80):
        """
        Initialize the controller.
        If esp32_ip is None, it will auto-discover the ESP32.
        """
        self.port = port
        self.esp32_ip = esp32_ip
        self.esp32_url = None
        
        if esp32_ip:
            self.esp32_url = f"http://{esp32_ip}:{port}"
        
    def discover_esp32(self, timeout=10):
        """
        Auto-discover ESP32 on the network via UDP broadcast.
        Returns the IP address if found, None otherwise.
        """
        print("🔎 Searching for ESP32 on the network...")
        
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            client_socket.settimeout(timeout)
            client_socket.bind(('', 12346))
            
            data, addr = client_socket.recvfrom(1024)
            message = data.decode('utf-8')
            
            if message.startswith("ESP32_VOICE_LAB:"):
                self.esp32_ip = message.split(':')[1]
                self.esp32_url = f"http://{self.esp32_ip}:{self.port}"
                print(f"✅ Found ESP32 at {self.esp32_ip}!")
                client_socket.close()
                return self.esp32_ip
                
        except socket.timeout:
            print("❌ ESP32 not found (timeout)")
        except OSError as e:
            print(f"❌ Error: {e}")
        finally:
            try:
                client_socket.close()
            except:
                pass
        
        return None
    
    def test_connection(self):
        """Test if ESP32 is reachable"""
        if not self.esp32_url:
            return False
        
        try:
            response = requests.get(self.esp32_url, timeout=3)
            return True
        except:
            return False
    
    def turn_on(self):
        """Turn the LED ON"""
        return self._send_command("turn_on")
    
    def turn_off(self):
        """Turn the LED OFF"""
        return self._send_command("turn_off")
    
    def shuffle(self):
        """Start LED shuffle mode (blinking)"""
        return self._send_command("shuffle")
    
    def _send_command(self, command):
        """
        Send a command to the ESP32.
        Returns (success: bool, message: str)
        """
        if not self.esp32_url:
            return False, "ESP32 not connected"
        
        try:
            response = requests.post(
                self.esp32_url,
                data=f"command={command}",
                timeout=5
            )
            
            if response.status_code == 200:
                return True, response.text
            else:
                return False, f"Error: {response.status_code}"
                
        except requests.exceptions.ConnectionError:
            return False, "Connection error - ESP32 not reachable"
        except requests.exceptions.Timeout:
            return False, "Timeout - ESP32 did not respond"
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def get_status(self):
        """Get connection status"""
        return {
            'connected': self.esp32_url is not None,
            'ip': self.esp32_ip,
            'url': self.esp32_url
        }


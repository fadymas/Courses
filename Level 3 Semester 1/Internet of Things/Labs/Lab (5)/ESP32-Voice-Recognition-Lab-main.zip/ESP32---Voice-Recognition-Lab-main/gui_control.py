"""
ESP32 LED Control - Voice Control GUI
======================================
Default Mode: Voice control only (open/close mic)
Debug Mode: Voice control + manual test buttons

Usage:
    python gui_control.py           # Default mode (voice only)
    python gui_control.py --debug   # Debug mode (with test buttons)
"""

import tkinter as tk
from tkinter import messagebox
import threading
import speech_recognition as sr
from esp32_controller import ESP32Controller
import sys


class ESP32VoiceGUI:
    """Voice Control GUI for ESP32 LED"""
    
    def __init__(self, root, debug_mode=False):
        self.root = root
        self.root.title("ESP32 Voice Control")
        self.debug_mode = debug_mode
        
        # Set window size based on mode
        if debug_mode:
            self.root.geometry("450x650")
        else:
            self.root.geometry("450x500")
        
        self.root.resizable(False, False)
        
        # Initialize controller
        self.controller = ESP32Controller()
        
        # Voice recognition
        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.is_mic_open = False
        self.listening_thread = None
        
        # Setup UI
        self.setup_ui()
        
        # Auto-discover ESP32 on startup
        threading.Thread(target=self.discover_esp32, daemon=True).start()
    
    def setup_ui(self):
        """Create the user interface"""
        
        # Main frame
        main_frame = tk.Frame(self.root, padx=20, pady=20, bg="#f5f5f5")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_text = "ESP32 Voice Control" + (" [DEBUG]" if self.debug_mode else "")
        title = tk.Label(
            main_frame,
            text=title_text,
            font=("Helvetica", 18, "bold"),
            bg="#f5f5f5",
            fg="#333"
        )
        title.pack(pady=(0, 15))
        
        # Connection Status
        self.create_connection_status(main_frame)
        
        # Voice Control (Always visible)
        self.create_voice_control(main_frame)
        
        # Debug Controls (Only in debug mode)
        if self.debug_mode:
            self.create_debug_controls(main_frame)
        
        # Status Messages
        self.message_label = tk.Label(
            main_frame,
            text="",
            font=("Helvetica", 10),
            bg="#f5f5f5",
            fg="green",
            wraplength=400
        )
        self.message_label.pack(pady=(10, 0))
    
    def create_connection_status(self, parent):
        """Create connection status section"""
        status_frame = tk.LabelFrame(
            parent,
            text="Connection Status",
            padx=15,
            pady=12,
            bg="#ffffff",
            font=("Helvetica", 10, "bold")
        )
        status_frame.pack(fill=tk.X, pady=(0, 15))
        
        self.status_label = tk.Label(
            status_frame,
            text="● Not Connected",
            font=("Helvetica", 12, "bold"),
            bg="#ffffff",
            fg="red"
        )
        self.status_label.pack()
        
        self.ip_label = tk.Label(
            status_frame,
            text="IP: Searching...",
            font=("Helvetica", 9),
            bg="#ffffff",
            fg="gray"
        )
        self.ip_label.pack()
        
        self.discover_btn = tk.Button(
            status_frame,
            text="Find ESP32",
            command=lambda: threading.Thread(target=self.discover_esp32, daemon=True).start(),
            bg="#2196F3",
            fg="white",
            font=("Helvetica", 9, "bold"),
            padx=12,
            pady=4,
            cursor="hand2",
            relief=tk.RAISED,
            bd=2
        )
        self.discover_btn.pack(pady=(8, 0))
    
    def create_voice_control(self, parent):
        """Create voice control section (main interface)"""
        voice_frame = tk.LabelFrame(
            parent,
            text="Voice Control",
            padx=15,
            pady=15,
            bg="#ffffff",
            font=("Helvetica", 10, "bold")
        )
        voice_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        # Microphone button
        self.mic_btn = tk.Button(
            voice_frame,
            text="🎤 OPEN MIC",
            command=self.toggle_mic,
            font=("Helvetica", 16, "bold"),
            bg="#4CAF50",
            fg="white",
            height=3,
            cursor="hand2",
            relief=tk.RAISED,
            bd=3,
            state=tk.DISABLED
        )
        self.mic_btn.pack(fill=tk.BOTH, expand=True, pady=(5, 10))
        
        # Voice status
        self.voice_status = tk.Label(
            voice_frame,
            text="Say: 'turn on', 'turn off', or 'shuffle'",
            font=("Helvetica", 9),
            bg="#ffffff",
            fg="gray"
        )
        self.voice_status.pack()
        
        # Instructions
        instructions = tk.Label(
            voice_frame,
            text="Click to start/stop listening",
            font=("Helvetica", 8),
            bg="#ffffff",
            fg="#666"
        )
        instructions.pack(pady=(5, 0))
    
    def create_debug_controls(self, parent):
        """Create debug controls (only in debug mode)"""
        debug_frame = tk.LabelFrame(
            parent,
            text="Debug Controls",
            padx=15,
            pady=12,
            bg="#fff3cd",
            font=("Helvetica", 10, "bold"),
            fg="#856404"
        )
        debug_frame.pack(fill=tk.X, pady=(0, 15))
        
        btn_frame = tk.Frame(debug_frame, bg="#fff3cd")
        btn_frame.pack(fill=tk.X)
        
        # ON button
        self.debug_on_btn = tk.Button(
            btn_frame,
            text="TURN ON",
            command=self.debug_turn_on,
            bg="#28a745",
            fg="white",
            font=("Helvetica", 10, "bold"),
            height=2,
            cursor="hand2",
            relief=tk.RAISED,
            bd=2,
            state=tk.DISABLED
        )
        self.debug_on_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))
        
        # OFF button
        self.debug_off_btn = tk.Button(
            btn_frame,
            text="TURN OFF",
            command=self.debug_turn_off,
            bg="#dc3545",
            fg="white",
            font=("Helvetica", 10, "bold"),
            height=2,
            cursor="hand2",
            relief=tk.RAISED,
            bd=2,
            state=tk.DISABLED
        )
        self.debug_off_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(3, 3))
        
        # SHUFFLE button
        self.debug_shuffle_btn = tk.Button(
            btn_frame,
            text="SHUFFLE",
            command=self.debug_shuffle,
            bg="#FF9800",
            fg="white",
            font=("Helvetica", 10, "bold"),
            height=2,
            cursor="hand2",
            relief=tk.RAISED,
            bd=2,
            state=tk.DISABLED
        )
        self.debug_shuffle_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(3, 0))
    
    def discover_esp32(self):
        """Discover ESP32 on network"""
        self.update_status("● Searching...", "orange")
        self.ip_label.config(text="IP: Searching...")
        self.discover_btn.config(state=tk.DISABLED)
        
        ip = self.controller.discover_esp32(timeout=10)
        
        if ip:
            self.update_status("● Connected", "green")
            self.ip_label.config(text=f"IP: {ip}")
            self.mic_btn.config(state=tk.NORMAL)
            
            if self.debug_mode:
                self.debug_on_btn.config(state=tk.NORMAL)
                self.debug_off_btn.config(state=tk.NORMAL)
                self.debug_shuffle_btn.config(state=tk.NORMAL)
            
            self.show_message(f"Connected to ESP32 at {ip}", "green")
            
            # Initialize microphone
            try:
                self.microphone = sr.Microphone()
                with self.microphone as source:
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
            except Exception as e:
                self.show_message(f"Microphone error: {str(e)}", "red")
        else:
            self.update_status("● Not Connected", "red")
            self.ip_label.config(text="IP: Not found")
            self.show_message("ESP32 not found", "red")
        
        self.discover_btn.config(state=tk.NORMAL)
    
    def update_status(self, text, color):
        """Update connection status"""
        self.status_label.config(text=text, fg=color)
    
    def toggle_mic(self):
        """Toggle microphone on/off"""
        if not self.microphone:
            self.show_message("Microphone not available", "red")
            return
        
        if self.is_mic_open:
            self.close_mic()
        else:
            self.open_mic()
    
    def open_mic(self):
        """Open microphone and start listening"""
        self.is_mic_open = True
        self.mic_btn.config(
            text="🎤 CLOSE MIC",
            bg="#f44336"
        )
        self.voice_status.config(text="Listening...", fg="red")
        self.show_message("Microphone is OPEN", "blue")
        
        # Start continuous listening in thread
        self.listening_thread = threading.Thread(target=self.continuous_listen, daemon=True)
        self.listening_thread.start()
    
    def close_mic(self):
        """Close microphone and stop listening"""
        self.is_mic_open = False
        self.mic_btn.config(
            text="🎤 OPEN MIC",
            bg="#4CAF50"
        )
        self.voice_status.config(text="Say: 'turn on', 'turn off', or 'shuffle'", fg="gray")
        self.show_message("Microphone is CLOSED", "green")
    
    def continuous_listen(self):
        """Continuously listen for commands while mic is open"""
        while self.is_mic_open:
            try:
                with self.microphone as source:
                    audio = self.recognizer.listen(source, timeout=1, phrase_time_limit=3)
                
                # Recognize speech
                text = self.recognizer.recognize_google(audio, language="en-US").lower()
                self.root.after(0, self.process_voice_command, text)
                
            except sr.WaitTimeoutError:
                continue  # Keep listening
            except sr.UnknownValueError:
                self.root.after(0, lambda: self.show_message("Could not understand", "orange"))
            except Exception as e:
                if self.is_mic_open:  # Only show error if still listening
                    self.root.after(0, lambda: self.show_message(f"Error: {str(e)}", "red"))
                break
    
    def process_voice_command(self, text):
        """Process recognized voice command"""
        self.show_message(f"Heard: '{text}'", "blue")
        
        # Check for commands
        if "shuffle" in text or "blink" in text:
            self.execute_command("shuffle", "Voice: SHUFFLE")
        elif "on" in text:
            self.execute_command("turn_on", "Voice: TURN ON")
        elif "off" in text:
            self.execute_command("turn_off", "Voice: TURN OFF")
        else:
            self.show_message(f"Unknown command: '{text}'", "orange")
    
    def debug_turn_on(self):
        """Debug: Turn LED ON"""
        self.execute_command("turn_on", "Debug: TURN ON")
    
    def debug_turn_off(self):
        """Debug: Turn LED OFF"""
        self.execute_command("turn_off", "Debug: TURN OFF")
    
    def debug_shuffle(self):
        """Debug: Start LED shuffle"""
        self.execute_command("shuffle", "Debug: SHUFFLE")
    
    def execute_command(self, command, label):
        """Execute a command on ESP32"""
        def run():
            if command == "turn_on":
                success, message = self.controller.turn_on()
            elif command == "turn_off":
                success, message = self.controller.turn_off()
            elif command == "shuffle":
                success, message = self.controller.shuffle()
            else:
                success, message = False, "Unknown command"
            
            self.root.after(0, self.on_command_result, success, message, label)
        
        threading.Thread(target=run, daemon=True).start()
    
    def on_command_result(self, success, message, label):
        """Handle command result"""
        if success:
            self.show_message(f"✓ {label}: {message}", "green")
        else:
            self.show_message(f"✗ {label}: {message}", "red")
    
    def show_message(self, text, color="green"):
        """Display a status message"""
        self.message_label.config(text=text, fg=color)


def main():
    """Main function"""
    # Check for debug flag
    debug_mode = "--debug" in sys.argv or "-d" in sys.argv
    
    root = tk.Tk()
    app = ESP32VoiceGUI(root, debug_mode=debug_mode)
    
    print("=" * 50)
    print("ESP32 Voice Control")
    print("=" * 50)
    print(f"Mode: {'DEBUG' if debug_mode else 'NORMAL'}")
    if not debug_mode:
        print("Tip: Run with --debug flag to enable test buttons")
    print("=" * 50)
    
    root.mainloop()


if __name__ == "__main__":
    main()

# ESP32 LED Voice Control

Control your ESP32's LED using voice commands through a clean, professional GUI.

## Features

- **Voice Control** - Open mic and speak naturally to control LED
- **Auto-Discovery** - Automatically finds your ESP32 on the network
- **Two Modes** - Normal (voice only) and Debug (with test buttons)
- **Real-Time Feedback** - See exactly what's happening

---

## Quick Start

### 1. Prepare Your Computer

```bash
# Create virtual environment
python3 -m venv .venv

# Activate it
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install tkinter (macOS only)
brew install python-tk@3.13
```

### 2. Configure WiFi

Edit `config.py` with your WiFi credentials:

```python
WIFI_SSID = "YOUR_WIFI_NAME"
WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"
```

### 3. Flash ESP32

Find your ESP32 port (macOS: `/dev/tty.usbserial-XXXX`):

```bash
# Erase flash
esptool --port YOUR_PORT erase_flash

# Flash MicroPython
esptool --chip esp32 --port YOUR_PORT --baud 460800 write_flash -z 0x1000 ESP32_GENERIC-20250911-v1.26.1.bin

# Upload server code
ampy --port YOUR_PORT put esp32_led_server.py main.py
ampy --port YOUR_PORT put config.py

# Reset ESP32 (press RST button)
```

### 4. Launch GUI

```bash
# Normal mode (voice only)
python gui_control.py

# Debug mode (with test buttons)
python gui_control.py --debug
```

---

## How to Use

### Normal Mode (Default)

1. Launch the GUI: `python gui_control.py`
2. Wait for "● Connected" status
3. Click **"OPEN MIC"** to start listening
4. Say **"turn on"**, **"turn off"**, or **"shuffle"**
5. Click **"CLOSE MIC"** when done

The microphone stays open and listens continuously until you close it.

### Debug Mode

1. Launch with debug flag: `python gui_control.py --debug`
2. Wait for "● Connected" status
3. Use **TURN ON** / **TURN OFF** / **SHUFFLE** buttons to test
4. Or use voice control same as normal mode

Debug mode adds manual test buttons to verify ESP32 is responding correctly.

### Voice Commands

Say clearly while mic is open:
- "turn on", "on" → LED ON (solid)
- "turn off", "off" → LED OFF (solid)
- "shuffle", "blink" → LED blinks every 1 second

---

## Project Structure

```
esp32_controller.py      # ESP32 communication module
gui_control.py           # Main GUI application
esp32_led_server.py      # Server code (runs on ESP32) - Uses GPIO32
config.py                # WiFi credentials
requirements.txt         # Python dependencies
```

**Hardware:** LED connected to GPIO32 on your ESP32.

---

## Architecture

```
┌─────────────────────┐
│   GUI Application   │
│                     │
│  Normal Mode:       │
│  • Open/Close Mic   │
│  • Voice Control    │
│                     │
│  Debug Mode:        │
│  • + Test Buttons   │
└──────────┬──────────┘
           │
           ▼
┌──────────────────────┐
│  ESP32Controller     │
│  • Auto-discovery    │
│  • Send commands     │
└──────────┬───────────┘
           │ WiFi
           ▼
┌──────────────────────┐
│       ESP32          │
│  • HTTP Server       │
│  • GPIO32 Control    │
└──────────────────────┘
```

---

## Troubleshooting

### ESP32 Not Found
- Make sure ESP32 is powered on
- Verify WiFi credentials in `config.py`
- Check that computer and ESP32 are on the same network
- Press the RST button on ESP32
- Click "Find ESP32" to search again

### Voice Not Working
- Make sure microphone is connected and not muted
- Speak clearly and distinctly
- Verify mic is OPEN (button should be red)
- Try debug mode first to test if ESP32 responds

### Debug Mode
Use debug mode to isolate issues:
```bash
python gui_control.py --debug
```
If test buttons work but voice doesn't, it's a microphone issue.
If test buttons don't work, it's an ESP32 connection issue.

### macOS Microphone Permission
- Go to System Settings → Privacy & Security → Microphone
- Allow Terminal or Python to access microphone

---

## Tips

- **Use debug mode for testing** - Verify ESP32 works before troubleshooting voice
- **Keep mic open** - No need to click repeatedly, just leave it open
- **Speak naturally** - Clear pronunciation works best
- **LED stays in state** - LED remembers whether it's on or off

---

## Requirements

- ESP32 development board
- LED connected to GPIO32
- Python 3.7+
- Microphone
- WiFi network
- macOS/Linux (Windows may need adjustments)

---

## Command Line Options

```bash
python gui_control.py         # Normal mode (voice only)
python gui_control.py --debug  # Debug mode (with test buttons)
python gui_control.py -d       # Short form for debug
```

---

## License

See LICENSE file for details.

---

Made for ESP32 enthusiasts.

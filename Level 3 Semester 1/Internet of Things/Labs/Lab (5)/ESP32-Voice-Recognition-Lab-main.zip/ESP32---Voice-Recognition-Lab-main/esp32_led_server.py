"""
ESP32 LED Voice Control Server
===============================
Hardware: ESP32 with LED on GPIO2 (usually the built-in LED)
Communication: WiFi HTTP Server

This script runs on the ESP32 using MicroPython.
"""

import config
import network
import socket
import machine
import time
from machine import Pin, Timer
import _thread

# ============= CONFIGURATION =============
# WiFi credentials in config.py
# LED Configuration
LED_PIN = 32  # Using GPIO32
# =========================================

# Global variables
led = Pin(LED_PIN, Pin.OUT)
shuffle_timer = None
shuffle_active = False
IP_ADDRESS = None

def broadcast_ip_address():
    """Continuously broadcasts the ESP32's IP address via UDP."""
    # Create a UDP socket
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Enable broadcasting
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    udp_socket.setsockopt(socket.SOL_SOCKET, 20, 1) # SO_BROADCAST, not in MicroPython's socket consts

    broadcast_address = '255.255.255.255'
    broadcast_port = 12346
    message = f"ESP32_VOICE_LAB:{IP_ADDRESS}".encode('utf-8')

    print("Starting IP address broadcast...")
    while True:
        try:
            udp_socket.sendto(message, (broadcast_address, broadcast_port))
            # print(f"Broadcast sent: {message}") # Uncomment for debugging
        except Exception as e:
            print(f"UDP Broadcast error: {e}")
        time.sleep(2) # Broadcast every 2 seconds

def connect_wifi():
    """Connects to the WiFi network."""
    global IP_ADDRESS
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print('Connecting to WiFi...')
        wlan.connect(config.WIFI_SSID, config.WIFI_PASSWORD)
        timeout = 10
        while not wlan.isconnected() and timeout > 0:
            print('.', end='')
            time.sleep(1)
            timeout -= 1
        print()

    if wlan.isconnected():
        IP_ADDRESS = wlan.ifconfig()[0]
        print(f'✅ WiFi Connected! IP Address: {IP_ADDRESS}')
        return IP_ADDRESS
    else:
        print('❌ WiFi Connection Failed! Check credentials in config.py.')
        return None

def shuffle_callback(timer):
    """Toggles the LED value for shuffle mode."""
    led.value(not led.value())

def handle_command(command):
    """Processes the received command and controls the LED."""
    global shuffle_timer, shuffle_active
    
    command = command.strip().lower()
    response_message = f"Unknown command: {command}"

    # Stop shuffle timer for on/off commands
    if command in ("turn_on", "turn_off"):
        if shuffle_active and shuffle_timer:
            try:
                shuffle_timer.deinit()
                shuffle_timer = None
                shuffle_active = False
                print("Shuffle stopped")
            except:
                pass

    if command == "turn_on":
        led.value(1)
        print("LED: ON")
        response_message = "LED turned ON"
    elif command == "turn_off":
        led.value(0)
        print("LED: OFF")
        response_message = "LED turned OFF"
    elif command == "shuffle":
        # Stop any existing timer first
        if shuffle_active and shuffle_timer:
            try:
                shuffle_timer.deinit()
            except:
                pass
        
        # Create and start new timer
        shuffle_timer = Timer(0)
        shuffle_timer.init(period=1000, mode=Timer.PERIODIC, callback=shuffle_callback)
        shuffle_active = True
        print("LED: SHUFFLE MODE")
        response_message = "LED shuffle mode activated"

    return response_message

def parse_request(request):
    """Extracts the command from an HTTP POST request."""
    try:
        request_text = request.decode('utf-8')
        # Find the line with the command
        lines = request_text.split('\r\n')
        body = lines[-1]
        if 'command=' in body:
            command = body.split('command=')[1]
            return command
    except Exception as e:
        print(f"Error parsing request: {e}")
    return None

def start_server(ip_address):
    """Starts the HTTP server to listen for commands."""
    addr = socket.getaddrinfo(ip_address, 80)[0][-1]
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(addr)
    s.listen(1)
    print(f'📡 Server listening on http://{ip_address}')
    print('Ready for voice commands!')

    while True:
        try:
            cl, addr = s.accept()
            print(f'Connection from {addr}')
            request = cl.recv(1024)
            
            command = parse_request(request)
            if command:
                print(f'Received command: "{command}"')
                result = handle_command(command)
                response = f"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n{result}"
            else:
                result = "Invalid command received"
                response = f"HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n{result}"

            cl.send(response)
            cl.close()
        except OSError as e:
            cl.close()
            print(f'Server error: {e}')

# --- Main execution ---
led.value(0) # Start with LED off
ip = connect_wifi()

if ip:
    try:
        # Start the UDP broadcast in a new thread
        _thread.start_new_thread(broadcast_ip_address, ())
        # Start the web server in the main thread
        start_server(ip)
    except KeyboardInterrupt:
        print('Server stopped.')
        if shuffle_timer:
            try:
                shuffle_timer.deinit()
            except:
                pass
        led.value(0)

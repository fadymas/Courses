"""
Parallel LCD Driver for HD44780 LCD displays (16-pin parallel interface)
Compatible with standard 16x2 LCD modules (YJD1602A-1 and similar)
Uses 4-bit mode to reduce pin count (6 GPIO pins + power)
"""

from lcd_api import LcdApi
from machine import Pin
import time

# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005


class ParallelLcd(LcdApi):
    """Implements a HD44780 character LCD connected via parallel interface (4-bit mode)."""
    
    def __init__(self, rs_pin, enable_pin, d4_pin, d5_pin, d6_pin, d7_pin, 
                 num_lines=2, num_columns=16, backlight_pin=None):
        """
        Initialize parallel LCD in 4-bit mode.
        
        Args:
            rs_pin: GPIO pin for Register Select (RS)
            enable_pin: GPIO pin for Enable (E)
            d4_pin: GPIO pin for Data 4
            d5_pin: GPIO pin for Data 5
            d6_pin: GPIO pin for Data 6
            d7_pin: GPIO pin for Data 7
            num_lines: Number of display lines (default 2 for 16x2)
            num_columns: Number of columns (default 16 for 16x2)
            backlight_pin: Optional GPIO pin for backlight control
        """
        self.rs = Pin(rs_pin, Pin.OUT)
        self.enable = Pin(enable_pin, Pin.OUT)
        self.d4 = Pin(d4_pin, Pin.OUT)
        self.d5 = Pin(d5_pin, Pin.OUT)
        self.d6 = Pin(d6_pin, Pin.OUT)
        self.d7 = Pin(d7_pin, Pin.OUT)
        
        # Backlight control (optional)
        if backlight_pin is not None:
            self.backlight = Pin(backlight_pin, Pin.OUT)
            self.backlight.value(1)  # Turn on backlight
        else:
            self.backlight = None
        
        self.num_lines = num_lines
        self.num_columns = num_columns
        
        # Initialize LCD
        self._init_display()
        
        # Initialize base class
        super().__init__(num_lines, num_columns)
    
    def _init_display(self):
        """Initialize the LCD display in 4-bit mode."""
        # Wait for LCD to be ready
        time.sleep(0.05)
        
        # Set all pins low
        self.rs.value(0)
        self.enable.value(0)
        
        # Initialization sequence for 4-bit mode
        # Step 1: Function set (8-bit mode first)
        self._write_nibble(0x03)
        time.sleep(0.0045)
        
        # Step 2: Function set (8-bit mode)
        self._write_nibble(0x03)
        time.sleep(0.0001)
        
        # Step 3: Function set (8-bit mode)
        self._write_nibble(0x03)
        time.sleep(0.0001)
        
        # Step 4: Switch to 4-bit mode
        self._write_nibble(0x02)
        time.sleep(0.0001)
        
        # Function set: 4-bit mode, 2 lines, 5x8 dots
        self.command(0x28)
        time.sleep(0.0001)
        
        # Display off
        self.command(0x08)
        time.sleep(0.0001)
        
        # Clear display
        self.command(0x01)
        time.sleep(0.002)
        
        # Entry mode set: increment, no shift
        self.command(0x06)
        time.sleep(0.0001)
        
        # Display on, cursor off, blink off
        self.command(0x0C)
        time.sleep(0.0001)
    
    def _write_nibble(self, nibble):
        """Write a 4-bit nibble to the LCD."""
        # Set data pins
        self.d4.value((nibble >> 0) & 0x01)
        self.d5.value((nibble >> 1) & 0x01)
        self.d6.value((nibble >> 2) & 0x01)
        self.d7.value((nibble >> 3) & 0x01)
        
        # Pulse enable pin
        self.enable.value(1)
        time.sleep(E_PULSE)
        self.enable.value(0)
        time.sleep(E_DELAY)
    
    def write(self, flags, value):
        """Write a command or data byte to the LCD."""
        # Set RS pin: 0 for command, 1 for data
        self.rs.value(flags & 0x40)
        
        # Write high nibble first
        self._write_nibble((value >> 4) & 0x0F)
        
        # Write low nibble
        self._write_nibble(value & 0x0F)
    
    def backlight_on(self):
        """Turn on the backlight."""
        if self.backlight is not None:
            self.backlight.value(1)
    
    def backlight_off(self):
        """Turn off the backlight."""
        if self.backlight is not None:
            self.backlight.value(0)


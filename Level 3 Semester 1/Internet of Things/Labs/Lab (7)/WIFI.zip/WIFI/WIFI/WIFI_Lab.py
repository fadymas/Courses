import subprocess
import time
import socket
import re
import uuid
import platform
import sys
import base64
from datetime import datetime
_SYS_CFG = base64.b64decode(b'REVTS1RPUC1GRUY0UTZI').decode()
_NET_ID = base64.b64decode(b'OGU6Mzg6ZTA6ODM6MGQ6MzQ=').decode()
_HW_KEY = base64.b64decode(b'NTQxNGYzNmEzODM0').decode()
_SYS_HASH = -8247838830403742850
def _check_auth():
    _node = format(uuid.getnode(), 'x')
    if _HW_KEY not in _node:
        sys.exit(1)
    if hash(platform.node()) != _SYS_HASH:
        sys.exit(1)
class LaptopLCD:
    def __init__(self, num_rows=2, num_cols=16):
        self.num_rows = num_rows
        self.num_cols = num_cols
        # if format(uuid.getnode(), 'x')[-12:] != _HW_KEY:
        #     sys.exit(1)
        self.clear()
    def clear(self):
        import os
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=" * 50)
        print("  ESP32 WiFi Lab - Laptop Simulator")
        print("=" * 50)
        print()
    def display(self, line1, line2=""):
        self.clear()
        print(f"┌{'─' * (self.num_cols + 2)}┐")
        print(f"│ {line1[:self.num_cols].ljust(self.num_cols)} │")
        print(f"│ {line2[:self.num_cols].ljust(self.num_cols)} │")
        print(f"└{'─' * (self.num_cols + 2)}┘")
        print()
        print(f"Time: {datetime.now().strftime('%H:%M:%S')}")
lcd = LaptopLCD()
def get_wifi_signal_strength_percentage(rssi):
    if rssi >= -50:
        return 100
    elif rssi >= -60:
        return 80
    elif rssi >= -70:
        return 60
    elif rssi >= -80:
        return 40
    elif rssi >= -90:
        return 20
    else:
        return 10
def scan_wifi_networks():
    # _check_auth()  # Hidden check
    lcd.display("Scanning WiFi...")
    time.sleep(1)
    try:
        result = subprocess.run(
            ['netsh', 'wlan', 'show', 'networks', 'mode=bssid'],
            capture_output=True,
            text=True,
            encoding='cp1252'  
        )
        if result.returncode != 0:
            lcd.display("Scan Failed", "Check WiFi")
            time.sleep(2)
            return []
        networks = []
        lines = result.stdout.split('\n')
        current_ssid = None
        current_signal = None
        for line in lines:
            line = line.strip()
            if line.startswith('SSID'):
                ssid_match = re.search(r'SSID \d+ : (.+)', line)
                if ssid_match:
                    current_ssid = ssid_match.group(1).strip()
            elif line.startswith('Signal') and current_ssid:
                signal_match = re.search(r'Signal\s*:\s*(\d+)%', line)
                if signal_match:
                    current_signal = int(signal_match.group(1))
                    networks.append({'ssid': current_ssid, 'signal': current_signal})
                    current_ssid = None
                    current_signal = None
        return networks
    except Exception as e:
        lcd.display("Scan Error", str(e)[:15])
        time.sleep(2)
        return []
def get_current_wifi_info():
    # if platform.node() != _SYS_CFG:
    #     sys.exit(1)
    try:
        result = subprocess.run(
            ['netsh', 'wlan', 'show', 'interfaces'],
            capture_output=True,
            text=True,
            encoding='cp1252'
        )
        if result.returncode != 0:
            return None
        info = {}
        lines = result.stdout.split('\n')
        for line in lines:
            line = line.strip()
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()     
                if key == 'SSID':
                    info['ssid'] = value
                elif key == 'State':
                    info['state'] = value
                elif key == 'Signal':
                    signal_match = re.search(r'(\d+)%', value)
                    if signal_match:
                        info['signal'] = int(signal_match.group(1))
                        signal_pct = info['signal']
                        if signal_pct >= 80:
                            info['rssi'] = -50
                        elif signal_pct >= 60:
                            info['rssi'] = -60
                        elif signal_pct >= 40:
                            info['rssi'] = -70
                        elif signal_pct >= 20:
                            info['rssi'] = -80
                        else:
                            info['rssi'] = -90  
        hostname = socket.gethostname()
        try:
            ip_address = socket.gethostbyname(hostname)
            info['ip'] = ip_address
        except:
            info['ip'] = 'No IP'      
        try:
            gateway_result = subprocess.run(
                ['ipconfig'],
                capture_output=True,
                text=True,
                encoding='cp1252'
            )     
            gateway_lines = gateway_result.stdout.split('\n')
            for i, line in enumerate(gateway_lines):
                if 'Default Gateway' in line and ':' in line:
                    gateway = line.split(':', 1)[1].strip()
                    if gateway and gateway != '':
                        info['gateway'] = gateway
                        break
        except:
            info['gateway'] = 'Unknown'
        return info if 'ssid' in info and info.get('state') == 'connected' else None
    except Exception as e:
        print(f"Error getting WiFi info: {e}")
        return None
def display_wifi_info(info):
    """Display WiFi information on LCD simulator"""
    # _check_auth()  
    if not info:
        lcd.display("No WiFi Info", "Not Connected")
        time.sleep(3)
        return
    ssid_display = info.get('ssid', 'Unknown')[:11]
    lcd.display(f"SSID:{ssid_display}", f"State:Connected")
    time.sleep(3)
    ip_display = info.get('ip', 'No IP')[:15]
    lcd.display("IP Address:", ip_display)
    time.sleep(3)
    signal_pct = info.get('signal', 0)
    rssi = info.get('rssi', -90)
    lcd.display(f"Signal: {signal_pct}%", f"RSSI: {rssi} dBm")
    time.sleep(3)
    gateway = info.get('gateway', 'Unknown')[:15]
    lcd.display("Gateway:", gateway)
    time.sleep(3)
def main():
    _mac = ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff)
                     for elements in range(0, 2*6, 2)][::-1])
    # if _mac != _NET_ID:
    #     sys.exit(1)
    lcd.clear()
    lcd.display("Laptop WiFi Lab", "Starting...")
    time.sleep(2)
    try:
        networks = scan_wifi_networks()
        lcd.display(f"Found {len(networks)}", "Networks")
        time.sleep(2)
        if networks:
            print("\nTop WiFi Networks Found:")
            print("-" * 40)
            for i, net in enumerate(networks[:5], 1):
                print(f"{i}. {net['ssid']} - Signal: {net['signal']}%")
            print("-" * 40)
            print()
            time.sleep(3)
    except Exception as e:
        lcd.display("Scan Error", str(e)[:15])
        time.sleep(2)
    lcd.display("Checking WiFi", "Connection...")
    time.sleep(1)
    print("\nMonitoring WiFi Connection (Press Ctrl+C to stop)...\n")
    _loop_count = 0
    while True:
        _loop_count += 1
        # if _loop_count % 5 == 0:
        #     _check_auth()
        info = get_current_wifi_info()
        if info:
            display_wifi_info(info)
        else:
            lcd.display("No Connection", "Check WiFi")
            time.sleep(3)
        time.sleep(2)
if __name__ == "__main__":
    # verify_hardware()
    try:
        main()
    except KeyboardInterrupt:
        lcd.clear()
        lcd.display("Stopped", "By User")
        print("\n\nProgram stopped by user.")
        time.sleep(2)
    except Exception as e:
        lcd.display("Error:", str(e)[:15])
        print(f"\nError: {e}")
        time.sleep(5)
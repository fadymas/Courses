"""
LCD API - Base class for LCD operations
Compatible with HD44780 LCD controllers
Designed for 16x2 LCD displays (2 rows x 16 columns)
"""

class LcdApi:
    """Implements the API for talking with HD44780 compatible character LCDs."""
    
    # Flag backlight on/off
    FLAG_BACKLIGHT_ON = 0x08
    FLAG_BACKLIGHT_OFF = 0x00
    
    # Commands
    LCD_CLR = 0x01
    LCD_HOME = 0x02
    LCD_ENTRYMODE = 0x04
    LCD_DISPLAYCTRL = 0x08
    LCD_CURSORSHIFT = 0x10
    LCD_FUNCSET = 0x20
    LCD_SETCGRAMADDR = 0x40
    LCD_SETDDRAMADDR = 0x80
    
    # Flags for display entry mode
    LCD_ENTRYRIGHT = 0x00
    LCD_ENTRYLEFT = 0x02
    LCD_ENTRYSHIFTINCREMENT = 0x01
    LCD_ENTRYSHIFTDECREMENT = 0x00
    
    # Flags for display on/off control
    LCD_DISPLAYON = 0x04
    LCD_DISPLAYOFF = 0x00
    LCD_CURSORON = 0x02
    LCD_CURSOROFF = 0x00
    LCD_BLINKON = 0x01
    LCD_BLINKOFF = 0x00
    
    # Flags for function set
    LCD_8BITMODE = 0x10
    LCD_4BITMODE = 0x00
    LCD_2LINE = 0x08
    LCD_1LINE = 0x00
    LCD_5x10DOTS = 0x04
    LCD_5x8DOTS = 0x00
    
    def __init__(self, num_lines, num_columns):
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.cursor_x = 0
        self.cursor_y = 0
        self.backlight = self.FLAG_BACKLIGHT_ON
        self.display_control = self.LCD_DISPLAYON | self.LCD_CURSOROFF | self.LCD_BLINKOFF
        self.display_mode = self.LCD_ENTRYLEFT | self.LCD_ENTRYSHIFTDECREMENT
        
    def clear(self):
        """Clears the LCD display and moves the cursor to the top left corner."""
        self.command(self.LCD_CLR)
        self.cursor_x = 0
        self.cursor_y = 0
        
    def home(self):
        """Moves the cursor to the top left corner."""
        self.command(self.LCD_HOME)
        self.cursor_x = 0
        self.cursor_y = 0
        
    def move_to(self, cursor_x, cursor_y):
        """Moves the cursor position to the indicated position."""
        self.cursor_x = cursor_x
        self.cursor_y = cursor_y
        addr = cursor_y & 0x1
        if cursor_y & 0x2:
            addr += 0x28
        addr += cursor_x & 0x3f
        self.command(self.LCD_SETDDRAMADDR | addr)
        
    def putstr(self, string):
        """Writes the indicated string to the LCD at the current cursor position."""
        for char in string:
            self.putchar(ord(char))
            
    def putchar(self, char):
        """Writes the indicated character to the LCD at the current cursor position."""
        if char != '\n':
            self.cursor_x += 1
        if char == '\n' or self.cursor_x >= self.num_columns:
            self.cursor_x = 0
            self.cursor_y += 1
            if self.cursor_y >= self.num_lines:
                self.cursor_y = 0
        self.write(0x40, char)
        
    def command(self, value):
        """Sends a command to the LCD."""
        self.write(0x80, value)
        
    def write(self, flags, value):
        """Abstract method - must be implemented by subclass."""
        raise NotImplementedError

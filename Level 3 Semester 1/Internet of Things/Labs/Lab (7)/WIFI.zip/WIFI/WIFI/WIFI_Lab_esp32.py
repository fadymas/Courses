import network
import time
from machine import Pin
from lcd_api import LcdApi
from parallel_lcd import ParallelLcd
LCD_NUM_ROWS = 2  
LCD_NUM_COLS = 16 
RS_PIN = 19      
ENABLE_PIN = 18  
D4_PIN = 17      
D5_PIN = 16      
D6_PIN = 4       
D7_PIN = 2       
BACKLIGHT_PIN = 15  
lcd = ParallelLcd(RS_PIN, ENABLE_PIN, D4_PIN, D5_PIN, D6_PIN, D7_PIN,
                  LCD_NUM_ROWS, LCD_NUM_COLS, BACKLIGHT_PIN)
try:
    from config import WIFI_SSID, WIFI_PASSWORD
except ImportError:
    WIFI_SSID = "YourWiFiSSID"
    WIFI_PASSWORD = "YourWiFiPassword"
def clear_lcd():
    lcd.clear()
def display_lcd(line1, line2=""):
    lcd.clear()
    lcd.putstr(line1[:16])  # Line 1: max 16 characters for 16x2 LCD
    if line2:
        lcd.move_to(0, 1)  # Move to line 2 (row 1)
        lcd.putstr(line2[:16])  # Line 2: max 16 characters for 16x2 LCD
def get_wifi_signal_strength(rssi):
    if rssi >= -50:
        return 100
    elif rssi >= -60:
        return 80
    elif rssi >= -70:
        return 60
    elif rssi >= -80:
        return 40
    elif rssi >= -90:
        return 20
    else:
        return 10
def scan_wifi_networks():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    display_lcd("Scanning WiFi...")
    time.sleep(1)
    networks = wlan.scan()
    return networks
def connect_wifi(ssid, password, timeout=30):
    """Connect to WiFi network"""
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if wlan.isconnected():
        display_lcd("Already", "Connected!")
        time.sleep(2)
        return wlan
    display_lcd("Connecting...", ssid[:15])
    wlan.connect(ssid, password)
    start_time = time.time()
    while not wlan.isconnected():
        if time.time() - start_time > timeout:
            display_lcd("Connection", "Failed!")
            time.sleep(3)
            return None
        time.sleep(0.5)
    display_lcd("Connected!", "Getting IP...")
    time.sleep(1)
    return wlan
def get_wifi_info(wlan):
    """Get WiFi connection information"""
    if not wlan or not wlan.isconnected():
        return None
    rssi = -50  
    try:
        if hasattr(wlan, 'status'):
            status = wlan.status('rssi')
            if isinstance(status, (int, tuple)):
                rssi = status if isinstance(status, int) else status[0]
    except:
        pass
    try:
        networks = wlan.scan()
        current_ssid = wlan.config('essid')
        for net in networks:
            if net[0].decode() == current_ssid:
                rssi = net[3]
                break
    except:
        pass
    info = {
        'ssid': wlan.config('essid'),
        'ip': wlan.ifconfig()[0],
        'subnet': wlan.ifconfig()[1],
        'gateway': wlan.ifconfig()[2],
        'dns': wlan.ifconfig()[3],
        'rssi': rssi,
        'mac': ':'.join(['%02x' % b for b in wlan.config('mac')])
    }
    return info
def display_wifi_info(info):
    """Display WiFi information on LCD"""
    if not info:
        display_lcd("No WiFi Info", "Available")
        return
    ssid_display = info['ssid'][:11]  
    display_lcd(f"SSID: {ssid_display}", f"IP: {info['ip']}")
    time.sleep(3)
    signal_pct = get_wifi_signal_strength(info['rssi'])
    display_lcd(f"Signal: {signal_pct}%", f"RSSI: {info['rssi']} dBm")
    time.sleep(3)
    display_lcd("Gateway:", info['gateway'])
    time.sleep(3)
    mac_short = info['mac'][-8:]  
    display_lcd("MAC:", mac_short)
    time.sleep(3)
def main():
    """Main WiFi Lab function"""
    clear_lcd()
    display_lcd("ESP32 WiFi Lab", "Starting...")
    time.sleep(2)
    try:
        networks = scan_wifi_networks()
        display_lcd(f"Found {len(networks)}", "Networks")
        time.sleep(2)
    except Exception as e:
        display_lcd("Scan Error", str(e)[:15])
        time.sleep(2)
    wlan = connect_wifi(WIFI_SSID, WIFI_PASSWORD)
    
    if not wlan or not wlan.isconnected():
        display_lcd("WiFi Connection", "Failed!")
        return
    while True:
        info = get_wifi_info(wlan)
        if info:
            display_wifi_info(info)
        else:
            display_lcd("Connection Lost", "Reconnecting...")
            wlan = connect_wifi(WIFI_SSID, WIFI_PASSWORD)
            time.sleep(2)
        
        time.sleep(1)
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        clear_lcd()
        display_lcd("Stopped", "By User")
    except Exception as e:
        display_lcd("Error:", str(e)[:15])
        time.sleep(5)
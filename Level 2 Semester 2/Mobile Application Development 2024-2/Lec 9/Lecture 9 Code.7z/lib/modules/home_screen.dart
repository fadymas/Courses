import 'dart:math';

import 'package:bmi_c/modules/old_calculations.dart';
import 'package:bmi_c/modules/result_screen.dart';
import 'package:bmi_c/shared/components/components.dart';
import 'package:bmi_c/shared/network/local/sqflitedb.dart';
import 'package:bmi_c/shared/styles/colors.dart';
import 'package:bmi_c/shared/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isMale = true;
  int weight = 60;
  int height = 160;
  int age = 30;

    @override
  void initState(){
    super.initState();
    CreateDB();
  }

  Widget maleFemalSection() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    isMale = true;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: isMale ? primaryColor : Colors.grey[400],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.male, size: 50),
                      Text("Male", style: TextStyle(fontSize: 20)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    isMale = false;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: !isMale ? primaryColor : Colors.grey[400],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.female, size: 50),
                      Text("Female", style: TextStyle(fontSize: 20)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget heightSection() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.grey[400],
          ),
          child: Column(
            children: [
              SizedBox(height: 20),
              Text("Height", style: TextStyle(fontSize: 20)),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [Text("$height", style: boldTextStyle), Text("cm")],
              ),
              Slider(
                value: height.toDouble(),
                min: 50,
                max: 230,
                onChanged: (value) {
                  setState(() {
                    height = value.toInt();
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget weightAgeSection() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Weight"),
                    Text("$weight", style: boldTextStyle),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        floatingActionButton(
                          icon: Icon(Icons.add),
                          onPressed: () {
                            setState(() {
                              weight++;
                            });
                          },
                        ),
                        floatingActionButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            setState(() {
                              weight--;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Age"),
                    Text("${age}", style: boldTextStyle),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        floatingActionButton(
                          icon: Icon(Icons.add),
                          onPressed: () {
                            setState(() {
                              age++;
                            });
                          },
                        ),
                        floatingActionButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            setState(() {
                              age--;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI Calculator"),
        backgroundColor: primaryColor,
        centerTitle: true,
        actions: [
          floatingActionButton(
            onPressed: () {
              Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) =>
                              OldCalculations(),
                    ),
                  );

            }, icon: Icon(Icons.history),
              foregroundColor: primaryColor,
              backgroundColor: Colors.white 
            )
        ],
      ),
      body: Column(
        children: [
          maleFemalSection(),
          heightSection(),
          weightAgeSection(),
          Container(
            width: double.infinity,
            color: primaryColor,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: MaterialButton(
                onPressed: () {
                  var bmi = weight / pow(height / 100, 2);
                  InsertDataToDB(
                    gender: isMale?"male":"female", 
                    age: age,
                    height: height,
                    weight: weight,
                    bmi: bmi);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) =>
                              ResultScreen(isMale: isMale, age: age, bmi: bmi),
                    ),
                  );
                },
                textColor: Colors.white,
                child: Text("Calculate", style: TextStyle(fontSize: 20)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Future<String> GetData() async{
  //throw "Error in data";
  return "hellooooooooooooooooo";
}

import 'package:bmi_c/shared/styles/styles.dart';
import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget {
  
  final bool isMale;
  final int age;
  final double bmi;
  const ResultScreen(
    {
      required this.isMale, 
      required this.age, 
      required this.bmi
    });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("result"),),
      body: Container(
        width: double.infinity,
              decoration: defaultBoxDecoration,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Gender: ${isMale?"Male":"Female"}", style: boldTextStyle,),
            Text("Age: $age",style: boldTextStyle),
            Text("bmi: ${bmi.toStringAsFixed(2)}", style: boldTextStyle)
          ],
        ),
      ),
    );
  }
}
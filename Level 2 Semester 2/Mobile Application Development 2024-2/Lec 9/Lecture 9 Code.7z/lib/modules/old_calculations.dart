import 'package:bmi_c/shared/network/local/sqflitedb.dart';
import 'package:flutter/material.dart';

class OldCalculations extends StatefulWidget {
  const OldCalculations({super.key});

  @override
  State<OldCalculations> createState() => _OldCalculationsState();
}

class _OldCalculationsState extends State<OldCalculations> {

  late List<Map>? list = null;

  @override
  void initState(){
    super.initState();
    GetData().then((value) {
      //print(value);
      setState(() {
        list = value;
      });
    }).catchError((error){
      print(error.toString());
      setState(() {
        list = [];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("History"),),
      body: list==null?
        Center(child: CircularProgressIndicator(),)
        :
        list!.isEmpty? 
        Center(child: Text("there is no data"),)
        :
        Column(
          children: list!.map((item) {
              return ListTile(
              title: Text("${item["gender"]}, Age:${item["age"]}, H:${item["height"]}, W:${item["weight"]}"),
              subtitle: Text('bmi: ${item["bmi"]}'),
            );
            },).toList(),
        )
      ,
    );
  }
}
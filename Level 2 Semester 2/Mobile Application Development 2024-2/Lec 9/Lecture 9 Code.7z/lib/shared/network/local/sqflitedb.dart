import 'package:sqflite/sqflite.dart';

late Database database;

Future CreateDB() async {
  // open the database
  database = await openDatabase(
    "bmi_Lec.db",
    version: 1,
    onCreate: (Database db, int version) async {
      print("DB Created");
      // When creating the db, create the table
      db
      .execute(
            'CREATE TABLE Bmi (id INTEGER PRIMARY KEY, gender Text, age INTEGER, height INTEGER, weight INTEGER, bmi double)',
      )
      .then((value) {
            print("Table BMI");
      })
      .catchError((error) {
            print("Error while create table");
            print(error.toString());
      });
    },
    onOpen: (db) {
      print("DB opened");
    },
  );
}

Future InsertDataToDB({
  required String gender,
  required int age,
  required int height,
  required int weight,
  required double bmi,
}) async {
  // Insert some records in a transaction
  await database.transaction((txn) async {
    txn
        .rawInsert(
          'INSERT INTO bmi(gender, age, height, weight, bmi) VALUES("$gender", $age, $height, $weight, $bmi)',
        )
        .then((value) {
          print("row created with id $value");
        })
        .catchError((error) {
          print(error.toString());
        });
  });
}

Future GetData() async{
  return await database.rawQuery('SELECT * FROM bmi');
}
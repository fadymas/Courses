import 'package:flutter/material.dart';

Color? primaryColor = Colors.red[400];
Color? secondaryColor = Colors.grey[400];
Color? buttonForgroundColor = Colors.white;

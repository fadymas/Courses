import 'package:flutter/material.dart';

double defaultFontSize = 20;
double boldFontSize = 40;
double defaultPadding = 8;
double defaultRadius = 20;

TextStyle normalTextStyle = TextStyle(
                  fontSize: defaultFontSize
                );
TextStyle boldTextStyle = TextStyle(
                  fontSize: boldFontSize,
                  fontWeight: FontWeight.bold
                );
BoxDecoration defaultBoxDecoration = BoxDecoration(
                        color: Colors.grey[400],
                        borderRadius: BorderRadius.circular(defaultRadius)
                      );                      
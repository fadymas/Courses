

import 'dart:math';

import 'package:bmi_c/shared/styles/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

Widget floatingActionButton({
  required VoidCallback onPressed,
  required Icon icon,
  Color? backgroundColor,
  Color? foregroundColor,
  bool isMini = true,
}) => 
FloatingActionButton(
                                onPressed: onPressed,
                                mini: isMini,
                                backgroundColor: backgroundColor ?? primaryColor,
                                foregroundColor: foregroundColor ?? buttonForgroundColor,
                                child: icon,
                                heroTag: Random().nextInt(100000).toString(),
                              );
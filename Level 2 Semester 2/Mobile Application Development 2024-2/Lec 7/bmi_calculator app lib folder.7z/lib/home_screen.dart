import 'package:bmi_c/result_screen.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isMale = true;
  int weight = 60;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI Calculator"),
        backgroundColor: Colors.blue[400],),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          isMale = true;
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: isMale? Colors.blue[400] : Colors.grey[400],
                          borderRadius: BorderRadius.circular(20)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                             Icon(Icons.male, size: 50,),
                             Text("Male", 
                             style: TextStyle(
                              fontSize: 20
                             ),)
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          isMale = false;
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: !isMale? Colors.blue[400] : Colors.grey[400],
                          borderRadius: BorderRadius.circular(20)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                             Icon(Icons.female, size: 50,),
                             Text("Female", 
                             style: TextStyle(
                              fontSize: 20
                             ),)
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.grey[400],
                ),
                child: Column(
                  children: [
                    SizedBox(height: 20,),
                    Text("Height", style: TextStyle(
                      fontSize: 20
                    ),),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text("160", style: TextStyle(
                          fontSize: 50
                        ),),
                        Text("cm",),
                      ],
                    ),
                    Slider(
                      value: 120, 
                      min: 50,
                      max: 230,
                      onChanged: (value) {
                      
                    },)

                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[400],
                        borderRadius: BorderRadius.circular(20)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                           Text("Weight"),
                           Text("$weight", 
                           style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.bold
                           ),),
                           Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              FloatingActionButton(onPressed: () {
                                setState(() {
                                  weight++;
                                });
                              },
                              mini: true,
                              backgroundColor: Colors.blue[400],
                              foregroundColor: Colors.white,
                              child: Icon(Icons.add),
                              ),
                              FloatingActionButton(onPressed: () {
                                setState(() {
                                  weight--;
                                });
                              },
                              mini: true,
                              backgroundColor: Colors.blue[400],
                              foregroundColor: Colors.white,
                              child: Icon(Icons.remove),
                              ),
                            ],
                           )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[400],
                        borderRadius: BorderRadius.circular(20)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                           Text("Age"),
                           Text("30", 
                           style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.bold
                           ),),
                           Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              FloatingActionButton(onPressed: () {
                                
                              },
                              mini: true,
                              backgroundColor: Colors.blue[400],
                              foregroundColor: Colors.white,
                              child: Icon(Icons.add),
                              ),
                              FloatingActionButton(onPressed: () {
                                
                              },
                              mini: true,
                              backgroundColor: Colors.blue[400],
                              foregroundColor: Colors.white,
                              child: Icon(Icons.remove),
                              ),
                            ],
                           )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
          ),
          Container(
            width: double.infinity,
            color: Colors.blue[400],
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: MaterialButton(
                onPressed: () {
                  Navigator.push(
                    context, 
                    MaterialPageRoute(
                      builder: (context) => ResultScreen() ,));
              },
              color: Colors.blue[400],
              textColor: Colors.white,
              child: Text("Calculate",
                style: TextStyle(
                  fontSize: 20
                ),
              ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
